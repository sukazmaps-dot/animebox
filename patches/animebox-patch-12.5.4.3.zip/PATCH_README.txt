AnimeBox Patch 12.5.4.3 — Home Visual Cascade Cleanup

HOW TO APPLY
1. Extract this ZIP into the root of your AnimeBox project.
2. Allow replacement of existing files.
3. Run:
   npm run dev

WHAT IT FIXES
- section-title marker no longer overlaps title text;
- marker has one stable size/alignment across Home sections;
- Continue Watching heading uses the same marker grammar;
- Mood divider spans the full Home content width again;
- Mood controls remain compact and left aligned.

SOURCE COMMIT
ce15ccba4c1e7891a3b816e66a1319983b48cd73
