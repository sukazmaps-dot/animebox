AnimeBox Patch 12.5.5 — Mobile Motion + Player Identity v2

Base code commit: 9ad541c3babd8e35de22cb3fe14bd1a81c69911d

HOW TO APPLY
1. Stop npm run dev.
2. Extract this ZIP into the root of your current animebox project.
3. Allow overwrite for existing files.
4. Run: npm run dev
5. Verify mobile bottom navigation and the episode player.

WHAT CHANGED
- Mobile nav: hysteresis, cooldown, input/modal lock, calmer animation.
- Player: denser media-first header and compact controls.
- Resume cover: smaller dark play CTA, no ping/glow rings.
- Source reliability: Auto mode falls back when selected provider has no URL.
- Missing source state: explicit alternative-source action.
- Error/loading/bottom navigation surfaces use one AnimeBox visual language.

Catalog/Saved/multi-genre/year/status/mood behavior remains from Patch 12.5.2.
